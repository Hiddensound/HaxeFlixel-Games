This is a Haxe port of Revenge demo from Yadu Rajiv (https://github.com/yadurajiv). Original code can be found at https://github.com/yadurajiv/revenge

Additional info: Presentation about game making with Flixel available here - http://www.slideshare.net/yadurajiv/making-games-with-flixel